# AI-Resume-Screening-System

**AI-based system for automated resume screening and candidate matching**

---

## 📌 Project Overview

This project automates the recruitment process using Artificial Intelligence
by analysing resumes and matching candidates with job descriptions.

Built as the MCA Final Year Project at **Chandigarh University Online**,
the system uses NLP-based resume parsing (spaCy) and Machine Learning-based
scoring (TF-IDF + cosine similarity via scikit-learn) to rank candidates
objectively against a job description.

---

## 🚀 Features

- **Resume Parsing using NLP** — spaCy named entity recognition extracts
  candidate name, email, skills, experience, and education from raw text
- **Skill Extraction** — matches against a 2 500-entry skills taxonomy using
  PhraseMatcher
- **Candidate Matching Algorithm** — TF-IDF cosine similarity + skill overlap
  + experience weighting
- **Automated Scoring System** — produces a 0–100 match score with
  shortlisted / under review / rejected status
- **REST API** — Flask endpoints for `/match`, `/parse_resume`, `/candidates`,
  `/shortlist`, `/jobs`

---

## 🛠️ Tech Stack

| Layer       | Technology                     |
|-------------|--------------------------------|
| Language    | Python 3.11                    |
| Framework   | Flask 3.0                      |
| NLP         | spaCy 3.7 (`en_core_web_lg`)   |
| ML          | scikit-learn 1.4 (TF-IDF)      |
| Data        | pandas, numpy                  |
| PDF Parsing | PyMuPDF (fitz)                 |
| DOCX        | python-docx                    |

---

## 📁 Project Structure

```
AI-Resume-Screening-System/
│
├── app.py               ← Flask application & all API routes
├── matcher.py           ← Core NLP + ML matching engine
├── data_generator.py    ← Synthetic candidate dataset generator
├── requirements.txt     ← Python dependencies
├── .gitignore
├── README.md
│
├── docs/
│   └── flow_definition.md   ← Resume processing flow (ASCII + tables)
│
├── sample_data/
│   ├── candidates.json       ← 10 sample candidate records
│   └── job_descriptions.json ← Job descriptions used by matcher
│
└── screenshots/
    ├── api_running.png
    ├── open_browser.png
    └── output.png
```

---

## ⚙️ Setup Instructions

### 1. Clone the repository

```bash
git clone https://github.com/maha2806/AI-Resume-Screening-System.git
cd AI-Resume-Screening-System
```

### 2. Create a virtual environment

```bash
python -m venv venv
source venv/bin/activate        # Linux / macOS
venv\Scripts\activate           # Windows
```

### 3. Install dependencies

```bash
pip install -r requirements.txt
```

### 4. Download spaCy model

```bash
python -m spacy download en_core_web_lg
```

### 5. (Optional) Generate sample dataset

```bash
python data_generator.py --count 20 --seed 42
```

### 6. Run the application

```bash
python app.py
```

Server starts at **http://127.0.0.1:5000**

---

## 📊 Sample Input

**Request — POST http://127.0.0.1:5000/match**

```json
{
  "name"        : "Rahul Sharma",
  "skills"      : ["Python", "SQL", "Machine Learning"],
  "experience"  : 2,
  "resume_text" : "Experienced Python developer with 2 years building Flask APIs and working with PostgreSQL databases. Familiar with scikit-learn for machine learning tasks."
}
```

---

## 📈 Output

**Response — 200 OK**

```json
{
  "candidate_name"    : "Rahul Sharma",
  "match_score"       : 85.0,
  "skill_overlap"     : 0.75,
  "tfidf_similarity"  : 0.68,
  "experience_score"  : 1.0,
  "matched_skills"    : ["Python", "SQL", "Machine Learning"],
  "missing_skills"    : ["Flask", "REST API", "Git"],
  "status"            : "shortlisted",
  "job_matched"       : "Python Developer"
}
```

---

## 🔗 API Endpoints

| Method | Endpoint        | Description                            |
|--------|-----------------|----------------------------------------|
| GET    | `/`             | Health check / system info             |
| POST   | `/match`        | Match resume to active job description |
| POST   | `/parse_resume` | Extract structured data from resume    |
| GET    | `/candidates`   | List all screened candidates           |
| POST   | `/shortlist`    | Auto-shortlist above threshold         |
| GET    | `/jobs`         | Return active job descriptions         |

---

## 🧮 Scoring Algorithm

```
Final Score = (TF-IDF Cosine × 0.45
             + Skill Overlap  × 0.40
             + Exp Score      × 0.15) × 100
```

| Score | Status       |
|-------|--------------|
| ≥ 65  | Shortlisted  |
| 40–64 | Under Review |
| < 40  | Rejected     |

---

## 📸 Screenshots

### API Running
![API Running](screenshots/api_running.png)

### Open Browser
![Open Browser](screenshots/open_browser.png)

### Match Result
![Match Result](screenshots/output.png)

---

## 👨‍💻 Author

**Rahul Sharma** — MCA Final Year Project
Chandigarh University Online — Batch 2022–2024

---

## 📄 License

This project is submitted as an academic project. For educational use only.
