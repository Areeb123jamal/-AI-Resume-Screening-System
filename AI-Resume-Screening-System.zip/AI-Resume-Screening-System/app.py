# ============================================================
#  AI Resume Screening System — app.py
#  Main Flask Application Entry Point
#  Author : Rahul Sharma (MCA Project)
#  Tech   : Python 3.11 | Flask 3.0 | spaCy | scikit-learn
# ============================================================

from flask import Flask, request, jsonify
from matcher import ResumeMatcher
import json
import os

# ─── App Initialisation ─────────────────────────────────────
app = Flask(__name__)
matcher = ResumeMatcher()

# ─── Routes ─────────────────────────────────────────────────

@app.route('/', methods=['GET'])
def index():
    """Health-check / welcome endpoint."""
    return jsonify({
        "system"  : "AI Resume Screening System",
        "version" : "1.0.0",
        "status"  : "running",
        "endpoints": [
            "POST /match          — Match a resume to a job description",
            "POST /parse_resume   — Extract skills/info from raw resume text",
            "GET  /candidates     — List all screened candidates",
            "POST /shortlist      — Auto-shortlist by score threshold",
            "GET  /jobs           — Return active job descriptions"
        ]
    }), 200


@app.route('/match', methods=['POST'])
def match_resume():
    """
    Match a candidate resume against a job description.

    Request JSON:
        {
            "name"       : "Rahul Sharma",
            "skills"     : ["Python", "SQL", "Machine Learning"],
            "experience" : 2,
            "resume_text": "Experienced Python developer..."   (optional)
        }

    Response JSON:
        {
            "candidate_name"  : "Rahul Sharma",
            "match_score"     : 85.0,
            "skill_overlap"   : 0.75,
            "tfidf_similarity": 0.62,
            "experience_score": 1.0,
            "matched_skills"  : ["Python", "SQL"],
            "missing_skills"  : ["Machine Learning"],
            "status"          : "shortlisted"
        }
    """
    data = request.get_json(silent=True)

    # ── Input validation ──────────────────────────────────────
    if not data:
        return jsonify({"error": "Request body must be valid JSON."}), 400

    required_fields = ["name", "skills", "experience"]
    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"Missing required field: '{field}'"}), 400

    if not isinstance(data["skills"], list) or len(data["skills"]) == 0:
        return jsonify({"error": "'skills' must be a non-empty list."}), 400

    # ── Run matching engine ──────────────────────────────────
    result = matcher.compute_match_score(
        candidate_name  = data["name"],
        candidate_skills= data["skills"],
        experience_years= float(data.get("experience", 0)),
        resume_text     = data.get("resume_text", "")
    )

    return jsonify(result), 200


@app.route('/parse_resume', methods=['POST'])
def parse_resume():
    """
    NLP-based resume parsing endpoint.
    Extracts structured information from raw resume text.

    Request JSON:
        { "resume_text": "John Doe\njohn@email.com\nSkills: Python, SQL..." }

    Response JSON:
        {
            "name"      : "John Doe",
            "email"     : "john@email.com",
            "skills"    : ["Python", "SQL"],
            "experience": 3,
            "education" : "B.Tech Computer Science"
        }
    """
    data = request.get_json(silent=True)

    if not data or "resume_text" not in data:
        return jsonify({"error": "Missing 'resume_text' in request body."}), 400

    parsed = matcher.parse_resume_text(data["resume_text"])
    return jsonify(parsed), 200


@app.route('/candidates', methods=['GET'])
def list_candidates():
    """
    Return all screened candidates stored in session memory,
    sorted by match_score descending.

    Query params:
        ?status=shortlisted   — filter by status
        ?min_score=60         — filter by minimum score
    """
    candidates = matcher.get_all_candidates()

    # ── Optional filters ──────────────────────────────────────
    status_filter    = request.args.get('status')
    min_score_filter = request.args.get('min_score', type=float)

    if status_filter:
        candidates = [c for c in candidates if c.get('status') == status_filter]

    if min_score_filter is not None:
        candidates = [c for c in candidates if c.get('match_score', 0) >= min_score_filter]

    # ── Sort by score descending ──────────────────────────────
    candidates = sorted(candidates, key=lambda x: x.get('match_score', 0), reverse=True)

    return jsonify({
        "total"     : len(candidates),
        "candidates": candidates
    }), 200


@app.route('/shortlist', methods=['POST'])
def shortlist_candidates():
    """
    Auto-shortlist all stored candidates above a given threshold.

    Request JSON:
        { "threshold": 65 }   (default: 65)

    Response JSON:
        {
            "shortlisted_count": 3,
            "shortlisted"      : [ {...}, {...} ]
        }
    """
    data      = request.get_json(silent=True) or {}
    threshold = float(data.get("threshold", 65))

    shortlisted = matcher.shortlist(threshold)

    return jsonify({
        "threshold"        : threshold,
        "shortlisted_count": len(shortlisted),
        "shortlisted"      : shortlisted
    }), 200


@app.route('/jobs', methods=['GET'])
def list_jobs():
    """Return active job descriptions used by the matcher."""
    jobs = matcher.get_job_descriptions()
    return jsonify({"jobs": jobs}), 200


# ─── Entry Point ─────────────────────────────────────────────
if __name__ == '__main__':
    print("=" * 55)
    print("  AI Resume Screening System — Starting Server")
    print("  URL : http://127.0.0.1:5000")
    print("  Test: POST http://127.0.0.1:5000/match")
    print("=" * 55)
    app.run(debug=True, host='0.0.0.0', port=5000)
